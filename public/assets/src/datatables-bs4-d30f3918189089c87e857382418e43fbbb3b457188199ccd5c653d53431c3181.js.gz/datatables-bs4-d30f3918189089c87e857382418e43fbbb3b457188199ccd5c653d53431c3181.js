import DataTable from "datatables.net-bs4"
window.DataTable = DataTable();
