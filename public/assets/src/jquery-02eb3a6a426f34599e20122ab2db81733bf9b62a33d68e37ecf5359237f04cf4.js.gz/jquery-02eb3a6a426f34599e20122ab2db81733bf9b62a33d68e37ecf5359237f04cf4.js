import jquery from "jquery"
global.jQuery = jquery
global.$ = jquery;
