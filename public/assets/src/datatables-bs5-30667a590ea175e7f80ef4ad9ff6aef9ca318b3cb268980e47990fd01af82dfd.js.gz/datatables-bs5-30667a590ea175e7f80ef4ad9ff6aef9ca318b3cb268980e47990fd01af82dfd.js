import DataTable from "datatables.net-bs5"
window.DataTable = DataTable();
